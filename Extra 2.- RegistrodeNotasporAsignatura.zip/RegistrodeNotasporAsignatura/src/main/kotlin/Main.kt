package org.example

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    val notasAsignaturas = mutableMapOf(
        "Matematicas" to mutableListOf(7.0, 6.5, 5.5),
        "Lenguaje" to mutableListOf(5.0, 5.5, 6.5),
        "Historia" to mutableListOf(6.5, 7.0, 4.5)
    )

    var seguir = true
    while (seguir) {
        println("---------- Menu de Asignaturas ----------")
        println("1.- Agregar notas a una asignatura")
        println("2.- Ver todas las notas de una asignatura")
        println("3.- Clacula el promedio de una asignatura")
        println("4.- Listar asignaturas con su promedio")
        println("5.- Encontrar la asignatura con el mejor promedio")
        println("6.- Salir")
        println("Elija una opción: ")
        var opcion = readln()?.toIntOrNull()?: 0

        when (opcion) {
            1 -> {
                println("Escriba el nombre de la asignatura: ")
                var asignatura = readln()?: ""
                if (asignatura == ""){
                    println("Debe escribir el nombre de una asignatura")
                }else{
                    println("Escriba la nota que debe porner: ")
                    var nota = readln()?.toDoubleOrNull()?: 0.0
                    if (nota == 0.0){
                        println("Nota no valida")
                    }else{
                        notasAsignaturas.getOrPut(asignatura) { mutableListOf()}.add(nota)
                        println("Se guardo con éxito la nota $nota en la asignatura $asignatura")
                    }
                }
            }
            2 -> {
                println("Escriba el nombre de la asignatura: ")
                var asignatura = readln()?: ""
                if (asignatura == ""){
                    println("Debe escribir el nombre de una asignatura")
                }else{
                    if(notasAsignaturas.containsKey(asignatura)) println("$asignatura: ${notasAsignaturas[asignatura]}")
                    else println("$asignatura no valida")
                }
            }
            3 -> {
                println("Escriba el nombre de la asignatura: ")
                var asignatura = readln()?: ""
                if (asignatura == ""){
                    println("Debe escribir el nombre de una asignatura")
                }else{
                    val notas = notasAsignaturas[asignatura]
                    if (notas != null) {
                        val promedio = notas.average()
                        println("El promedio de $asignatura es: $promedio")
                    } else {
                        println("La asignatura '$asignatura' no existe o no tiene notas registradas.")
                    }
                }
            }
            4 -> {
                if (notasAsignaturas.isEmpty()) {
                    println("No hay asignaturas registradas.")
                } else {
                    println("---------- Promedios por Asignatura ----------")
                    for ((asignatura, notas) in notasAsignaturas) {
                        val promedio = if (notas.isNotEmpty()) notas.average() else 0.0
                        println("- $asignatura: $promedio")
                    }
                }
            }
            5 -> {
                if (notasAsignaturas.isEmpty()) {
                    println("No hay asignaturas registradas.")
                } else {
                    // maxByOrNull busca el elemento del mapa con el mayor promedio
                    val mejorAsignatura = notasAsignaturas.maxByOrNull { entry ->
                        if (entry.value.isNotEmpty()) entry.value.average() else 0.0
                    }

                    if (mejorAsignatura != null) {
                        val promedioMejor = mejorAsignatura.value.average()
                        println("La asignatura con mejor promedio es '${mejorAsignatura.key}' con un promedio de $promedioMejor")
                    }
                }
            }
            6 -> {
                seguir = false
                println("¡Saliendo del programa. Éxito en tus estudios!")
            }
            else ->{
                println("Opción no valida, ingrese una opción correcta")
            }
        }
    }
}