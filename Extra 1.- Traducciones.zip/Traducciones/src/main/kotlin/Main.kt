package org.example

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    val traducciones: MutableMap<String, String> = mutableMapOf(
        "Comer" to "Eat",
        "Jugar" to "Play",
        "Disfruta" to "Enjoy",
        "Odio" to "Hate"
    )

    var seguir = true
    while(seguir){
        println("*** Menú de Traducciones ***")
        println("1.- Agregar una nueva palabra y su traducción")
        println("2.- Buscar la traducción de una palabra existente")
        println("3.- Editar la traducción de una palabra existente")
        println("4.- Eliminar una palabra del diccionario")
        println("5.- Listar todo el diccionario ordenado por clave")
        println("6.- Buscar palabras cuya traducción contenga un texto dado")
        println("7.- Salir")
        println("Seleccione una opción: ")
        var opcion = readln()?.toIntOrNull()?: 0

        when (opcion) {
            1 -> {
                var palabra: String
                var traduccion: String
                println("Escribe la palabra: ")
                palabra = readln() ?: ""
                if(palabra == "") {
                    println("Debe escribir una palabra")
                }else{
                    println("Escribe su traducción: ")
                    traduccion = readln() ?: ""
                    if (traduccion == "") {
                        println("Debe escribir su traducción")
                    }else{
                        traducciones[palabra] = traduccion
                        println("La palabra $palabra se a añadido con exito")
                    }
                }
            }
            2 -> {
                println("Escriba la palabra que quiere buscar: ")
                val palabra = readln() ?: ""
                if(palabra == "" ){
                    println("Debe escribir una palabra")
                }else {
                    if(traducciones.contains(palabra)) println("La palabra $palabra tiene traducción, la cual es ${traducciones[palabra]}")
                    else println("La palabra $palabra no tiene traducción aún")
                }
            }
            3 -> {
                var palabra: String
                var traduccion: String
                println("Escribe la palabra que desea cambiar su traducción: ")
                palabra = readln() ?: ""
                if(palabra == "") {
                    println("Debe escribir una palabra")
                }else{
                    println("Escribe su nueva traducción: ")
                    traduccion = readln() ?: ""
                    if (traduccion == "") {
                        println("Debe escribir su traducción")
                    }else{
                        if(traducciones.contains(palabra)) {
                            traducciones[palabra] = traduccion
                            println("La traducción de la palabra $palabra se a actualizado")
                        }else println("La palabra $palabra no existe en las traducciones")
                    }
                }
            }
            4 -> {
                var palabra: String
                println("Escriba la palabra que desea eliminar de las traducciones: ")
                palabra = readln() ?: ""
                if (palabra == "") {
                    println("Debe escribir una palabra")
                }else {
                    if (traducciones.contains(palabra)){
                        traducciones.remove(palabra)
                        println("La palabra $palabra se a borrado de las traducciones")
                    }else println("La palabra $palabra no existe en las traducciones")
                }
            }
            5 -> {
                println("---- Traducciones existentes ----")
                val clavesOrdenadas = traducciones.keys.sorted()
                for (clave in clavesOrdenadas) {
                    println("$clave -> ${traducciones[clave]}")
                }
            }
            6 -> {
                println("Escriba el texto a buscar dentro de las traducciones: ")
                val texto = readln() ?: ""
                if (texto.isBlank()) {
                    println("Debe escribir un texto de búsqueda.")
                } else {
                    val resultados = traducciones.filter { it.value.contains(texto, ignoreCase = true) }
                    if (resultados.isEmpty()) {
                        println("No se encontraron traducciones que contengan '$texto'.")
                    } else {
                        println("Resultados encontrados:")
                        for ((palabra, traduccion) in resultados) {
                            println("$palabra -> $traduccion")
                        }
                    }
                }
            }
            7 -> {
                seguir = false
                println("Hasta luego")
            }
            else -> {
                println("Opción no valida")
            }
        }
    }
}